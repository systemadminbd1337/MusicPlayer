<?php
include __DIR__ . "/_bootstrap.php";

// === KPI Counters ===
$total_users   = (int) $db->get_var("SELECT COUNT(*) FROM k_users WHERE deleted_at IS NULL");
$banned_users  = (int) $db->get_var("SELECT COUNT(*) FROM k_users WHERE is_banned=1 AND deleted_at IS NULL");
$total_credit  = (int) $db->get_var("SELECT COALESCE(SUM(kredi),0) FROM k_users WHERE deleted_at IS NULL");
$total_ann     = (int) $db->get_var("SELECT COUNT(*) FROM k_announcements");
$broken_links  = (int) $db->get_var("SELECT COUNT(*) FROM k_broken_links WHERE status='broken'");
$defunct_sites = (int) $db->get_var("SELECT COUNT(*) FROM k_broken_links WHERE status='defunct'");

// === Chart Data ===
$status_data = $db->get_results("SELECT last_status, COUNT(*) AS cnt FROM monitored_urls GROUP BY last_status", ARRAY_A);
$chart_labels = []; $chart_counts = [];
foreach($status_data as $row){ $chart_labels[] = $row['last_status']; $chart_counts[] = (int)$row['cnt']; }

$daily = $db->get_results("
    SELECT DATE(checked_at) as d, COUNT(*) as c
    FROM url_checks
    WHERE checked_at >= DATE_SUB(NOW(), INTERVAL 14 DAY)
    GROUP BY DATE(checked_at)
    ORDER BY d ASC
", ARRAY_A);
$chart_days = []; $chart_day_count = [];
foreach($daily as $d){ $chart_days[] = $d['d']; $chart_day_count[] = (int)$d['c']; }

// === Live Alerts ===
$alerts = $db->get_results("
  SELECT id, url, last_status, last_http_code, last_checked
  FROM monitored_urls
  WHERE last_status IN ('NOT_FOUND','GONE','ERROR','SERVER_ERROR','NOT_FOUND_CUSTOM')
  ORDER BY last_checked DESC
  LIMIT 10
", ARRAY_A);
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Admin • HackLink</title>
<meta name="viewport" content="width=device-width,initial-scale=1">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Share+Tech+Mono&family=Orbitron:wght@500;700&display=swap" rel="stylesheet">
<style>
:root{
  --bg:#030611;--panel:#071025;--muted:#9aa7be;
  --neon1:#00e6ff;--neon2:#00ff9d;--accent:#facc15;
}
body{
  margin:0;background:
    radial-gradient(1000px 300px at 10% 10%,rgba(0,230,255,0.03),transparent 5%),
    radial-gradient(800px 300px at 90% 90%,rgba(0,255,157,0.02),transparent 5%),
    var(--bg);
  color:#e6eef8;font-family:'Share Tech Mono',monospace;
}
.container{padding:28px 20px;max-width:1250px;}
.header{display:flex;justify-content:space-between;align-items:center;margin-bottom:20px;}
.h-title{font-size:22px;font-weight:800;color:var(--neon1);text-shadow:0 0 8px var(--neon1);}
.navx{display:flex;gap:10px;flex-wrap:wrap;}
.navx a{padding:8px 12px;border-radius:8px;color:#e6eef8;text-decoration:none;
background:rgba(255,255,255,0.03);border:1px solid rgba(96,165,250,0.08);transition:all .18s;}
.navx a:hover{transform:translateY(-3px);box-shadow:0 8px 26px rgba(0,255,157,0.05);color:var(--neon2);}
.grid{display:grid;grid-template-columns:repeat(3,1fr);gap:16px;margin-top:16px;}
.cardx{background:linear-gradient(180deg,rgba(255,255,255,0.02),rgba(255,255,255,0.01));
border-radius:12px;padding:18px;border:1px solid rgba(96,165,250,0.08);
box-shadow:0 12px 36px rgba(0,0,0,0.6);transition:all .25s;}
.cardx:hover{box-shadow:0 0 25px rgba(0,230,255,.15),inset 0 0 12px rgba(0,255,157,.08);}
.kpi{font-size:28px;font-weight:800;color:var(--accent);text-shadow:0 0 10px rgba(250,204,21,0.12);}
.small{color:var(--muted);font-size:13px;}
.chart-box{background:linear-gradient(180deg,rgba(255,255,255,0.02),rgba(255,255,255,0.01));
border:1px solid rgba(96,165,250,0.08);border-radius:12px;
box-shadow:0 0 25px rgba(0,230,255,.06),inset 0 0 10px rgba(0,255,157,.05);
padding:20px;margin-top:30px;}
.hack-subtitle{font-family:'Orbitron',sans-serif;color:var(--neon1);text-transform:uppercase;font-size:16px;margin-bottom:12px;}
.alert-box{margin-top:35px;padding:20px;border-radius:12px;border:1px solid rgba(255,80,80,0.2);
background:linear-gradient(180deg,rgba(60,10,10,0.2),rgba(0,0,0,0.2));
box-shadow:0 0 25px rgba(255,80,80,0.08),inset 0 0 10px rgba(255,80,80,0.1);}
.alert-row{padding:8px 0;border-bottom:1px solid rgba(255,255,255,0.05);}
.alert-status{color:#ff7171;font-weight:700;text-shadow:0 0 6px rgba(255,113,113,0.5);animation:blink 1.4s infinite alternate;}
@keyframes blink{from{opacity:0.7;}to{opacity:1;}}
.footer-note{text-align:center;margin-top:22px;color:#9fb0d6;font-size:13px;}
.progress{height:20px;background:#0b1b25;border:1px solid rgba(0,255,157,0.2);}
.progress-bar{background:linear-gradient(90deg,#00ff9d,#00e6ff);color:#001;font-size:12px;}
@media(max-width:900px){.grid{grid-template-columns:repeat(2,1fr)}}
@media(max-width:520px){.grid{grid-template-columns:1fr}}
</style>
</head>
<body>
<div class="container">
  <div class="header">
    <div>
      <div class="h-title">🧠 HackLink Admin Dashboard</div>
      <div class="small">Welcome back, <?= htmlspecialchars($user->username ?? 'admin') ?> — manage and monitor in real time.</div>
    </div>
    <div class="navx">
      <a href="index.php">Home</a>
      <a href="users.php">Users</a>
      <a href="announcements.php">Announcements</a>
      <a href="broken_links.php">Broken Links</a>
      <a href="login_logs.php">Logs</a>
	  <a href="user_login_logs.php">📜 User Login Logs</a>
      <a href="monitors.php" style="color:#00e6ff;">🔗 URL Monitor</a>
      <a href="deleted_sites.php" style="color:#ff7171;">🚫 Removed Sites</a>
      <a href="../index.php">Front</a>
      <a href="logout.php" style="color:#f87171;">Logout</a>
    </div>
  </div>

  <!-- KPI GRID -->
  <div class="grid">
    <div class="cardx"><div class="small">👤 Total Users</div><div class="kpi"><?= $total_users ?></div></div>
    <div class="cardx"><div class="small">🚫 Banned Users</div><div class="kpi"><?= $banned_users ?></div></div>
    <div class="cardx"><div class="small">💳 Total Credit</div><div class="kpi"><?= $total_credit ?></div></div>
    <div class="cardx"><div class="small">📢 Announcements</div><div class="kpi"><?= $total_ann ?></div></div>
    <div class="cardx"><div class="small">⚠️ Broken Links</div><div class="kpi text-warning"><?= $broken_links ?></div></div>
    <div class="cardx"><div class="small">💀 Defunct Sites</div><div class="kpi text-danger"><?= $defunct_sites ?></div></div>
  </div>

  <!-- CHARTS -->
  <div class="chart-box">
    <div class="row">
      <div class="col-md-6">
        <h5 class="hack-subtitle">🔸 URL Status Overview</h5>
        <canvas id="statusChart" height="260"></canvas>
      </div>
      <div class="col-md-6">
        <h5 class="hack-subtitle">📈 URL Checks (Last 14 Days)</h5>
        <canvas id="dailyChart" height="260"></canvas>
      </div>
    </div>
  </div>

  <!-- 🔔 LIVE ALERTS -->
  <div class="alert-box mt-4">
    <h5 class="hack-subtitle" style="color:#ff7171;">🔔 Live Alerts — Broken or Deleted URLs</h5>
    <?php if(!$alerts): ?>
      <div class="text-muted text-center py-3">✅ All clear — no broken or removed links detected.</div>
    <?php else: foreach($alerts as $a): ?>
      <div class="alert-row">
        <span class="alert-status"><?= htmlspecialchars($a['last_status']) ?></span>
        <a href="<?= htmlspecialchars($a['url']) ?>" target="_blank" style="color:#00e6ff;text-decoration:none;">
          <?= htmlspecialchars($a['url']) ?>
        </a>
        <small class="text-muted"> — HTTP <?= (int)$a['last_http_code'] ?> · <?= htmlspecialchars($a['last_checked']) ?></small>
      </div>
    <?php endforeach; endif; ?>
  </div>

  <!-- ===================== ⚡ BULK URL CHECKER ===================== -->
  <div class="chart-box mt-5 p-4">
    <h4 class="hack-subtitle mb-3" style="color:#00e6ff;">⚡ Bulk URL Checker (Live Progress)</h4>
    <div class="neon-card p-3 mb-3">
      <label class="form-label small">Paste URLs (one per line)</label>
      <textarea id="urls" class="form-control" rows="6" placeholder="https://example.com/page1&#10;https://example.com/page2"></textarea>
      <div class="form-check mt-2">
        <input class="form-check-input" type="checkbox" id="addToMonitors">
        <label class="form-check-label small" for="addToMonitors">Add checked URLs to monitored list</label>
      </div>
      <button class="btn btn-primary mt-3" id="startCheck">Start Checking</button>
    </div>

    <div class="progress mb-3 d-none" id="progressWrap">
      <div class="progress-bar" id="progressBar" style="width:0%">0%</div>
    </div>

    <div id="resultsArea" class="neon-card p-3 d-none">
      <h6 class="mb-2">Results</h6>
      <div class="table-responsive">
        <table class="table table-sm align-middle">
          <thead><tr><th>#</th><th>URL</th><th>Status</th><th>HTTP</th><th>Snippet</th></tr></thead>
          <tbody id="resultsBody"></tbody>
        </table>
      </div>
    </div>
  </div>

  <div class="footer-note">Tip: Alerts update automatically when Monitor runs. Use URL Monitor for manual check ⚡</div>
</div>

<!-- Chart.js -->
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js"></script>
<script>
// Donut chart
new Chart(document.getElementById('statusChart'),{
  type:'doughnut',
  data:{labels:<?= json_encode($chart_labels) ?>,datasets:[{data:<?= json_encode($chart_counts) ?>,
  backgroundColor:['#00e6ff','#00ff9d','#ffcb6b','#ff6b6b','#a855f7','#8b5cf6'],borderWidth:1,borderColor:'rgba(0,0,0,0.2)'}]},
  options:{plugins:{legend:{labels:{color:'#c7f9e8',font:{family:'Share Tech Mono'}}}}}
});
// Line chart
new Chart(document.getElementById('dailyChart'),{
  type:'line',
  data:{labels:<?= json_encode($chart_days) ?>,datasets:[{label:'Checks per Day',
  data:<?= json_encode($chart_day_count) ?>,borderColor:'#00e6ff',backgroundColor:'rgba(0,230,255,0.1)',fill:true,tension:0.3,
  borderWidth:2,pointRadius:3,pointBackgroundColor:'#00ff9d'}]},
  options:{scales:{x:{ticks:{color:'#8b9aa3'}},y:{ticks:{color:'#8b9aa3'}}},plugins:{legend:{labels:{color:'#c7f9e8'}}}}
});

// Bulk checker JS
document.getElementById('startCheck').addEventListener('click', async ()=>{
  const lines=document.getElementById('urls').value.trim().split(/\r?\n/).filter(Boolean);
  if(!lines.length){alert('Please enter URLs');return;}
  const add=document.getElementById('addToMonitors').checked;
  const total=lines.length;
  const wrap=document.getElementById('progressWrap'),bar=document.getElementById('progressBar');
  const area=document.getElementById('resultsArea'),tbody=document.getElementById('resultsBody');
  wrap.classList.remove('d-none');area.classList.remove('d-none');tbody.innerHTML='';
  bar.style.width='0%';bar.textContent='0%';
  for(let i=0;i<total;i++){
    const url=lines[i];
    let row=document.createElement('tr');
    row.innerHTML=`<td>${i+1}</td><td>${url}</td><td colspan="3">⏳ Checking...</td>`;
    tbody.appendChild(row);
    try{
      const fd=new FormData();fd.append('url',url);fd.append('add',add?'1':'0');
      const res=await fetch('check_single_ajax.php',{method:'POST',body:fd});
      const d=await res.json();
      let badge=d.status==='OK'?`<span class='badge bg-success'>${d.status}</span>`:`<span class='badge bg-danger'>${d.status}</span>`;
      row.innerHTML=`<td>${i+1}</td><td><a href='${d.url}' target='_blank' style='color:#00e6ff;'>${d.url}</a></td>
      <td>${badge}</td><td>${d.http_code||'-'}</td><td><small>${(d.response_snippet||'').slice(0,120)}</small></td>`;
    }catch(e){
      row.innerHTML=`<td>${i+1}</td><td>${url}</td><td colspan='3' style='color:#f66;'>Error: ${e}</td>`;
    }
    let pct=Math.round(((i+1)/total)*100);bar.style.width=pct+'%';bar.textContent=pct+'%';
    window.scrollTo({top:document.body.scrollHeight,behavior:'smooth'});
  }
  bar.textContent='Done ✅';
});
</script>
</body>
</html>
