<?php
include __DIR__ . "/_bootstrap.php";

// Admin guard
if (empty($user) || ($user->role ?? '') !== 'admin') {
    header("Location: login.php"); exit;
}

// Fetch recent login logs
$logs = $db->get_results("
    SELECT * FROM k_user_login_logs 
    ORDER BY created_at DESC 
    LIMIT 200
");
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>👤 User Login Logs — Admin</title>
<meta name="viewport" content="width=device-width,initial-scale=1">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<style>
body{background:#060717;color:#e6eef8;font-family:'Share Tech Mono',monospace;}
.container{max-width:1200px;margin-top:40px;}
h2{color:#00e6ff;text-shadow:0 0 8px rgba(0,230,255,.6);}
.table thead th{color:#00e6ff;}
.table tbody tr:hover{background:rgba(0,255,157,0.05);}
.badge-ok{background:linear-gradient(90deg,#00ff9d,#00e6ff);color:#001214;}
.badge-fail{background:linear-gradient(90deg,#ff5f5f,#ff9f7f);color:#120000;}
.cardx{background:rgba(255,255,255,0.02);border:1px solid rgba(0,255,157,0.1);border-radius:12px;padding:20px;}
.nav-back{color:#00e6ff;text-decoration:none;}
.nav-back:hover{text-decoration:underline;}

/* 🔥 Hacker Navbar */
.navx{
  display:flex;flex-wrap:wrap;gap:8px;
  background:linear-gradient(90deg,rgba(255,255,255,0.04),rgba(255,255,255,0.02));
  border:1px solid rgba(255,255,255,0.05);
  border-radius:12px;
  padding:10px 15px;
  box-shadow:0 8px 30px rgba(0,0,0,0.6);
  justify-content:center;
  margin-bottom:25px;
}
.navx a{
  text-decoration:none;
  color:#e6eef8;
  background:rgba(96,165,250,0.1);
  padding:8px 14px;
  border-radius:8px;
  font-weight:500;
  transition:.2s;
}
.navx a:hover{
  background:linear-gradient(90deg,#60a5fa,#a855f7);
  color:#fff;
  text-shadow:0 0 8px rgba(96,165,250,0.5);
}
.logout-btn{
  background:linear-gradient(90deg,#ef4444,#b91c1c);
  padding:6px 14px;
  border-radius:8px;
  color:#fff;
  text-decoration:none;
  font-weight:600;
  transition:.2s;
}
.logout-btn:hover{box-shadow:0 0 15px rgba(239,68,68,.5);color:#fff;}
</style>
</head>
<body class="p-4">

<!-- 🔥 Hacker Navigation -->
<div class="container my-3">
  <div class="navx">
    <a href="index.php">🏠 Home</a>
    <a href="users.php">👥 Users</a>
    <a href="announcements.php">📢 Announcements</a>
    <a href="broken_links.php">🧩 Broken Links</a>
    <a href="login_logs.php">🧠 Admin Logs</a>
    <a href="user_login_logs.php" style="background:linear-gradient(90deg,#60a5fa,#a855f7);color:#fff;">📜 User Login Logs</a>
    <a href="monitors.php">🔗 URL Monitor</a>
    <a href="deleted_sites.php" style="color:#ff7171;">🚫 Removed Sites</a>
    <a href="refunds.php">💸 Refunds</a>
    <a href="../index.php">🌐 Front</a>
    <a href="logout.php" class="logout-btn">Logout</a>
  </div>
</div>

<div class="container">
  <div class="d-flex justify-content-between align-items-center mb-3">
    <h2>📜 User Login Logs</h2>
    <a href="index.php" class="nav-back">⬅ Back to Dashboard</a>
  </div>

  <div class="cardx">
    <div class="table-responsive">
      <table class="table table-sm align-middle">
        <thead>
          <tr>
            <th>#</th>
            <th>Username</th>
            <th>IP</th>
            <th>User Agent</th>
            <th>Status</th>
            <th>Date</th>
          </tr>
        </thead>
        <tbody>
        <?php if(!$logs): ?>
          <tr><td colspan="6" class="text-center text-muted">No login records found.</td></tr>
        <?php else: foreach($logs as $r): ?>
          <tr>
            <td><?=$r->id?></td>
            <td><?=htmlspecialchars($r->username ?? '-')?></td>
            <td><code><?=htmlspecialchars($r->ip ?? '-')?></code></td>
            <td><small><?=htmlspecialchars(substr($r->user_agent,0,80))?><?=strlen($r->user_agent)>80?'…':''?></small></td>
            <td>
              <?php if($r->success){ ?>
                <span class="badge badge-ok">SUCCESS</span>
              <?php } else { ?>
                <span class="badge badge-fail">FAILED</span>
              <?php } ?>
            </td>
            <td><small><?=htmlspecialchars($r->created_at)?></small></td>
          </tr>
        <?php endforeach; endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>
</body>
</html>
