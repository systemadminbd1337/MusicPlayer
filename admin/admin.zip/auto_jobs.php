<?php
// admin/auto_jobs.php
// Admin panel to monitor jobs (assume is_admin() function exists; add to your auth logic)

// Define esc() function to match link-depo.php
function esc($v) { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }

require_once '_bootstrap.php'; // Reference _bootstrap.php in htdocs/admin/
require_once '../db.php'; // Include db.php to define $db
// Start session if not already started in _bootstrap.php
if (session_status() === PHP_SESSION_NONE) {
  session_start();
}
// Check if user is logged in and has admin privileges
if (empty($_SESSION['user']) || !isset($_SESSION['user']->id)) {
  redirect("login.php"); // Redirect to login if session is invalid
  exit();
}
// if (!is_admin()) { redirect("login.php"); exit(); } // TODO: Implement admin check if needed in _bootstrap.php
$uid = (int)$_SESSION['user']->id; // For consistency, though admin

// Handle AJAX actions
if (!empty($_GET['ajax']) && $_SERVER['REQUEST_METHOD'] === 'POST') {
  header('Content-Type: application/json; charset=utf-8');
  $oid = (int)($_POST['oid'] ?? 0);
  if ($oid <= 0) { echo json_encode(['ok' => 0, 'msg' => 'Invalid order ID']); exit; }

  if ($_GET['ajax'] === 'retry') {
    $db->query("UPDATE k_orders SET status = 'pending', attempts = 0 WHERE id = '{$oid}' AND status IN ('pending', 'failed')");
    echo json_encode(['ok' => 1, 'msg' => 'Retry queued']);
    exit;
  }

  if ($_GET['ajax'] === 'force') {
    $db->query("UPDATE k_orders SET status = 'processing' WHERE id = '{$oid}'");
    include "../inc/auto_functions.php"; // For process_order
    process_order($oid);
    echo json_encode(['ok' => 1, 'msg' => 'Force processed']);
    exit;
  }

  echo json_encode(['ok' => 0, 'msg' => 'Unknown action']); exit;
}

// Stats
$pending = (int)$db->get_var("SELECT COUNT(*) FROM k_orders WHERE status = 'pending'");
$processing = (int)$db->get_var("SELECT COUNT(*) FROM k_orders WHERE status = 'processing'");
$processed = (int)$db->get_var("SELECT COUNT(*) FROM k_orders WHERE status = 'processed'");
$failed = (int)$db->get_var("SELECT COUNT(*) FROM k_orders WHERE status = 'failed'");
$total = $pending + $processing + $processed + $failed;
$success_rate = $total > 0 ? round(($processed / $total) * 100, 1) : 0;

// Rows (focus on issues: pending, processing, failed; LIMIT 100)
$rows = $db->get_results("SELECT o.id, o.uid, o.lid, o.status, o.attempts, o.notes, o.processed_at, u.username AS user_name, l.domain 
                          FROM k_orders o 
                          LEFT JOIN k_users u ON u.id = o.uid 
                          LEFT JOIN k_linkdb l ON l.id = o.lid 
                          WHERE o.status != 'processed' 
                          ORDER BY o.id DESC LIMIT 100");

// Fallback if no rows
if (empty($rows)) $rows = [];
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Auto Backlink Jobs</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.datatables.net/1.13.4/css/dataTables.bootstrap5.min.css" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" rel="stylesheet">
  <style>
    body {
      background: linear-gradient(135deg, #0e0c1d 0%, #1a1625 100%);
      color: #e0e0e0;
      font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
      padding-bottom: 2rem;
    }
    .container-fluid {
      max-width: 1400px;
      padding: 1rem;
    }
    .card {
      background: #161329;
      border: 1px solid rgba(159, 122, 234, 0.3);
      border-radius: 12px;
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.2);
      transition: transform 0.3s ease, box-shadow 0.3s ease;
    }
    .card:hover {
      transform: translateY(-4px);
      box-shadow: 0 8px 20px rgba(159, 122, 234, 0.2);
    }
    .card h5 {
      color: #9f7aea;
      font-weight: 600;
      font-size: 1.1rem;
      margin-bottom: 0.5rem;
    }
    .stats-box {
      font-size: 1.5rem;
      font-weight: 700;
      line-height: 1.2;
    }
    .header-title {
      font-size: 1.8rem;
      font-weight: 700;
      color: #fff;
      display: flex;
      align-items: center;
      gap: 0.5rem;
      margin-bottom: 1.5rem;
    }
    .table-container {
      background: #161329;
      border: 1px solid rgba(159, 122, 234, 0.3);
      border-radius: 12px;
      padding: 1rem;
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.2);
    }
    table.dataTable {
      color: #fff;
      border-collapse: separate;
      border-spacing: 0;
    }
    table.dataTable th, table.dataTable td {
      border: none;
      padding: 0.75rem;
      vertical-align: middle;
    }
    table.dataTable thead th {
      background: rgba(159, 122, 234, 0.1);
      border-bottom: 1px solid rgba(159, 122, 234, 0.3);
      font-weight: 600;
      text-transform: uppercase;
      font-size: 0.85rem;
      color: #b7a4ff;
    }
    table.dataTable tbody tr {
      transition: background 0.2s ease;
    }
    table.dataTable tbody tr:hover {
      background: rgba(159, 122, 234, 0.15);
    }
    .dataTables_filter {
      margin-bottom: 1rem;
    }
    .dataTables_filter input {
      background: #222;
      border: 1px solid rgba(159, 122, 234, 0.3);
      color: #fff;
      padding: 0.5rem;
      border-radius: 6px;
      transition: border-color 0.3s ease;
    }
    .dataTables_filter input:focus {
      border-color: #9f7aea;
      outline: none;
    }
    .dataTables_wrapper .dataTables_paginate .paginate_button {
      background: #222;
      color: #fff !important;
      border: 1px solid rgba(159, 122, 234, 0.3);
      border-radius: 6px;
      margin: 0 0.25rem;
      padding: 0.5rem 1rem;
      transition: all 0.3s ease;
    }
    .dataTables_wrapper .dataTables_paginate .paginate_button:hover {
      background: #9f7aea;
      border-color: #9f7aea;
      color: #fff !important;
    }
    .dataTables_wrapper .dataTables_paginate .paginate_button.current {
      background: #9f7aea !important;
      border-color: #9f7aea !important;
      color: #fff !important;
    }
    .btn-retry {
      background: linear-gradient(90deg, #f59e0b, #d97706);
      border: none;
      border-radius: 6px;
      padding: 0.4rem 0.8rem;
      font-weight: 600;
      transition: transform 0.2s ease, box-shadow 0.2s ease;
    }
    .btn-retry:hover {
      transform: translateY(-2px);
      box-shadow: 0 4px 8px rgba(245, 158, 11, 0.3);
    }
    .btn-force {
      background: linear-gradient(90deg, #10b981, #059669);
      border: none;
      border-radius: 6px;
      padding: 0.4rem 0.8rem;
      font-weight: 600;
      transition: transform 0.2s ease, box-shadow 0.2s ease;
    }
    .btn-force:hover {
      transform: translateY(-2px);
      box-shadow: 0 4px 8px rgba(16, 185, 129, 0.3);
    }
    .badge {
      font-size: 0.75rem;
      font-weight: 600;
      padding: 0.4rem 0.6rem;
      border-radius: 6px;
    }
    .badge.bg-warning { background: #f59e0b; }
    .badge.bg-info { background: #06b6d4; }
    .badge.bg-danger { background: #ef4444; }
    @media (max-width: 768px) {
      .container-fluid { padding: 0.5rem; }
      .header-title { font-size: 1.4rem; }
      .card { margin-bottom: 1rem; }
      .stats-box { font-size: 1.2rem; }
      .row.g-3 { margin-left: -0.5rem; margin-right: -0.5rem; }
      .col-md-3, .col-md-12 { padding: 0.5rem; }
      table.dataTable { font-size: 0.85rem; }
      table.dataTable th, table.dataTable td { padding: 0.5rem; }
      .btn-retry, .btn-force { font-size: 0.75rem; padding: 0.3rem 0.6rem; }
    }
    @media (max-width: 576px) {
      .dataTables_filter input { width: 100%; }
      .dataTables_wrapper .dataTables_paginate { text-align: center; }
      .btn-retry, .btn-force { width: 100%; margin-bottom: 0.5rem; }
      .action-buttons { display: flex; flex-direction: column; gap: 0.5rem; }
    }
  </style>
</head>
<body>
<div class="container-fluid mt-4">
  <h3 class="header-title">
    <i class="fas fa-cogs"></i> Auto Backlink Jobs
  </h3>

  <!-- Stats -->
  <div class="row g-3 mb-4">
    <div class="col-md-3 col-sm-6">
      <div class="card p-3 text-center">
        <h5>Pending</h5>
        <div class="stats-box text-warning"><?= $pending ?></div>
      </div>
    </div>
    <div class="col-md-3 col-sm-6">
      <div class="card p-3 text-center">
        <h5>Processing</h5>
        <div class="stats-box text-info"><?= $processing ?></div>
      </div>
    </div>
    <div class="col-md-3 col-sm-6">
      <div class="card p-3 text-center">
        <h5>Processed</h5>
        <div class="stats-box text-success"><?= $processed ?></div>
      </div>
    </div>
    <div class="col-md-3 col-sm-6">
      <div class="card p-3 text-center">
        <h5>Failed</h5>
        <div class="stats-box text-danger"><?= $failed ?></div>
      </div>
    </div>
    <div class="col-md-12 col-sm-12">
      <div class="card p-3 text-center">
        <h5>Success Rate</h5>
        <div class="stats-box text-primary"><?= $success_rate ?>%</div>
      </div>
    </div>
  </div>

  <!-- Table of issues -->
  <div class="table-container">
    <div class="table-responsive">
      <table id="jobsTable" class="table table-dark table-striped align-middle" style="width:100%">
        <thead>
          <tr>
            <th>ID</th>
            <th>User</th>
            <th>Domain</th>
            <th>Status</th>
            <th>Attempts</th>
            <th>Processed At</th>
            <th>Notes</th>
            <th class="action-buttons">Action</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($rows as $r): ?>
          <tr>
            <td><?= esc($r->id) ?></td>
            <td><?= esc($r->user_name ?? 'Unknown') ?></td>
            <td><?= esc($r->domain ?? 'Unknown') ?></td>
            <td><span class="badge <?= $r->status == 'failed' ? 'bg-danger' : ($r->status == 'pending' ? 'bg-warning' : 'bg-info') ?>"><?= esc(strtoupper($r->status)) ?></span></td>
            <td><?= esc($r->attempts) ?></td>
            <td><?= esc($r->processed_at ?? '-') ?></td>
            <td><?= nl2br(esc(substr($r->notes ?? '', 0, 100))) ?>...</td>
            <td class="action-buttons">
              <button class="btn btn-sm btn-retry retry-btn" data-oid="<?= esc($r->id) ?>">Retry</button>
              <button class="btn btn-sm btn-force force-btn" data-oid="<?= esc($r->id) ?>">Force Process</button>
            </td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<?php include "../footer.php"; ?>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.13.4/js/dataTables.bootstrap5.min.js"></script>
<script>
$(function(){
  $('#jobsTable').DataTable({
    pageLength: 10,
    responsive: true,
    columnDefs: [
      { targets: -1, orderable: false } // Disable sorting on Action column
    ]
  });

  // Retry button
  $(document).on('click', '.retry-btn', function(){
    const oid = $(this).data('oid');
    $.post('auto_jobs.php?ajax=retry', {oid: oid}, function(res){
      if(res.ok){
        alert('Retry queued successfully');
        location.reload();
      } else {
        alert(res.msg || 'Failed');
      }
    }, 'json');
  });

  // Force process button
  $(document).on('click', '.force-btn', function(){
    const oid = $(this).data('oid');
    $.post('auto_jobs.php?ajax=force', {oid: oid}, function(res){
      if(res.ok){
        alert('Force processed successfully');
        location.reload();
      } else {
        alert(res.msg || 'Failed');
      }
    }, 'json');
  });
});
</script>
</body>
</html>