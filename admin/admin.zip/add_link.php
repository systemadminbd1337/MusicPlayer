<?php
// admin/add_link.php — Hacker Neon Theme (Only Add Link Form)

require_once __DIR__ . "/_bootstrap.php";

// safety
if (!isset($db)) { die("Database not connected. Ensure admin/_bootstrap.php loads correctly."); }

// helpers
function esc($v){ return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
function dbx($v){ global $db; return (isset($db) && method_exists($db,'escape')) ? $db->escape($v) : addslashes($v); }
function has_col($table, $col){
  global $db;
  try{
    $c = (int)$db->get_var("SELECT COUNT(*) FROM information_schema.columns WHERE table_schema=DATABASE() AND table_name='".dbx($table)."' AND column_name='".dbx($col)."'");
    return $c>0;
  }catch(Throwable $e){ return false; }
}
function json_exit($arr){
  if (!headers_sent()) header('Content-Type: application/json; charset=utf-8');
  echo json_encode($arr); exit;
}

// detect optional columns
$col_domain_year = has_col('k_linkdb','domain_year');
$col_sure        = has_col('k_linkdb','sure');
$col_ups         = has_col('k_linkdb','ups');
$col_alexa1      = has_col('k_linkdb','alexa1');
$col_alexa2      = has_col('k_linkdb','alexa2');
$col_country     = has_col('k_linkdb','country');
$col_created_at  = has_col('k_linkdb','created_at'); // Explicitly check for created_at

// AJAX endpoint: add link (no CSRF)
if ($_SERVER['REQUEST_METHOD']==='POST' && ($_POST['ajax']??'')==='add_link') {
  try {
    $domain = trim($_POST['domain'] ?? '');
    $type   = (int)($_POST['type'] ?? 1);
    $ups    = (int)($_POST['ups'] ?? 1);
    $pa     = (int)($_POST['alexa1'] ?? 0);
    $da     = (int)($_POST['alexa2'] ?? 0);
    $year   = trim($_POST['domain_year'] ?? '');
    $sure   = trim($_POST['sure'] ?? '');
    $country= trim($_POST['country'] ?? '');

    if ($domain==='') json_exit(['ok'=>0,'msg'=>'Domain required.']);
    $d = preg_replace('#^https?://#i','',$domain); // Case-insensitive protocol removal
    $d = rtrim($d,'/');
    $d = strtolower($d); // Normalize domain to lowercase for consistency

    // duplicate check on domain (case-insensitive)
    $dup = (int)$db->get_var("SELECT COUNT(*) FROM k_linkdb WHERE LOWER(domain)='".dbx(strtolower($d))."'");
    if ($dup>0) json_exit(['ok'=>0,'msg'=>'Domain already exists.']);

    // dynamic insert
    $cols = ["domain","tip"];
    $vals = ["'".dbx($d)."'","'".$type."'"];
    if ($col_ups)       { $cols[]="ups";         $vals[]="'".dbx($ups)."'"; }
    if ($col_alexa1)    { $cols[]="alexa1";      $vals[]="'".dbx($pa)."'"; }
    if ($col_alexa2)    { $cols[]="alexa2";      $vals[]="'".dbx($da)."'"; }
    if ($col_domain_year){$cols[]="domain_year"; $vals[]="'".dbx($year)."'"; }
    if ($col_sure)      { $cols[]="sure";        $vals[]="'".dbx($sure)."'"; }
    if ($col_country)   { $cols[]="country";     $vals[]="'".dbx($country)."'"; }
    if (has_col('k_linkdb','durum')) { $cols[]="durum"; $vals[]="'1'"; } // Ensure visible
    if ($col_created_at) { $cols[]="created_at"; $vals[]="NOW()"; } // Ensure created_at is set

    $sql = "INSERT INTO k_linkdb(".implode(',',$cols).") VALUES(".implode(',',$vals).")";
    $db->query($sql);
    $insert_id = $db->insert_id; // Get the ID of the inserted link for debugging

    // Log for debugging
    error_log("Link added: domain=$d, id=$insert_id, sql=$sql");

    json_exit(['ok'=>1,'msg'=>'✅ Link added successfully!','insert_id'=>$insert_id]);
  } catch(Throwable $e){
    error_log("Add link error: ".$e->getMessage());
    json_exit(['ok'=>0,'msg'=>'Server error: '.$e->getMessage()]);
  }
}
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Admin • Add Link — HackLink</title>
<meta name="viewport" content="width=device-width,initial-scale=1">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Share+Tech+Mono&family=Orbitron:wght@500;700&display=swap" rel="stylesheet">
<style>
:root{
  --bg:#030611;--panel:#071025;--muted:#9aa7be;
  --neon1:#00e6ff;--neon2:#00ff9d;--accent:#facc15;
}
body{
  margin:0;
  background:
    radial-gradient(1000px 300px at 10% 10%,rgba(0,230,255,0.03),transparent 5%),
    radial-gradient(800px 300px at 90% 90%,rgba(0,255,157,0.02),transparent 5%),
    var(--bg);
  color:#e6eef8;
  font-family:'Share Tech Mono',monospace;
}
.container{padding:28px 20px;max-width:1250px;}
.header{display:flex;justify-content:space-between;align-items:center;margin-bottom:20px;}
.h-title{font-size:22px;font-weight:800;color:var(--neon1);text-shadow:0 0 8px var(--neon1);}
.navx{display:flex;gap:10px;flex-wrap:wrap;}
.navx a{padding:8px 12px;border-radius:8px;color:#e6eef8;text-decoration:none;
background:rgba(255,255,255,0.03);border:1px solid rgba(96,165,250,0.08);transition:all .18s;}
.navx a:hover{transform:translateY(-3px);box-shadow:0 8px 26px rgba(0,255,157,0.05);color:var(--neon2);}
.cardx{background:linear-gradient(180deg,rgba(255,255,255,0.02),rgba(255,255,255,0.01));
border-radius:12px;padding:18px;border:1px solid rgba(96,165,250,0.08);
box-shadow:0 12px 36px rgba(0,0,0,0.6);transition:all .25s;}
.cardx:hover{box-shadow:0 0 25px rgba(0,230,255,.15),inset 0 0 12px rgba(0,255,157,.08);}
.form-label{color:var(--muted);font-size:13px;}
.form-control{background:rgba(0,0,0,0.35);border:1px solid rgba(255,255,255,0.04);color:#e6eef8}
.btn-neon{background:linear-gradient(90deg,var(--neon2),var(--neon1));border:none;color:#001214;font-weight:700}
.small{color:var(--muted);font-size:13px;}
.footer-note{text-align:center;margin-top:22px;color:#9fb0d6;font-size:13px;}
</style>
</head>
<body>
<div class="container">
  <div class="header">
    <div>
      <div class="h-title">🧠 HackLink Admin — Add Link</div>
      <div class="small">Welcome back, <?= esc($user->username ?? 'admin') ?> — Add new market link</div>
    </div>
    <div class="navx">
      <a href="index.php">Home</a>
      <a href="users.php">Users</a>
      <a href="announcements.php">Announcements</a>
      <a href="broken_links.php">Broken Links</a>
      <a href="login_logs.php">Logs</a>
      <a href="user_login_logs.php">📜 User Login Logs</a>
      <a href="monitors.php">🔗 URL Monitor</a>
      <a href="deleted_sites.php">🚫 Removed Sites</a>
      <a href="../index.php">Front</a>
      <a href="logout.php" style="color:#f87171;">Logout</a>
      <a href="payments.php" style="color:#00ff9d;">Payments</a>
    </div>
  </div>

  <div class="cardx mb-3">
    <h5 style="font-family:'Orbitron',sans-serif;color:var(--neon1);font-weight:700">➕ Add New Link</h5>
    <form id="addLinkForm" autocomplete="off">
      <input type="hidden" name="ajax" value="add_link">
      <div class="row g-3 mt-2">
        <div class="col-md-4">
          <label class="form-label">Domain (example.com)</label>
          <input name="domain" id="domain" class="form-control" required>
        </div>
        <div class="col-md-3">
          <label class="form-label">Type</label>
          <select name="type" id="type" class="form-select form-control">
            <option value="1">PHP</option>
            <option value="2">JS</option>
            <option value="3">Other</option>
          </select>
        </div>
        <div class="col-md-2">
          <label class="form-label">Credit (ups)</label>
          <input name="ups" id="ups" class="form-control" type="number" value="1" min="1">
        </div>
        <div class="col-md-1">
          <label class="form-label">PA</label>
          <input name="alexa1" id="alexa1" class="form-control" type="number" value="0">
        </div>
        <div class="col-md-1">
          <label class="form-label">DA</label>
          <input name="alexa2" id="alexa2" class="form-control" type="number" value="0">
        </div>
      </div>

      <div class="row g-3 mt-3">
        <div class="col-md-3">
          <label class="form-label">Domain Year</label>
          <input name="domain_year" id="domain_year" class="form-control" placeholder="e.g. 2015">
        </div>
        <div class="col-md-3">
          <label class="form-label">Duration (days)</label>
          <input name="sure" id="sure" class="form-control" placeholder="e.g. 365">
        </div>
        <div class="col-md-3">
          <label class="form-label">Country</label>
          <input name="country" id="country" class="form-control" placeholder="e.g. US">
        </div>
      </div>

      <div class="mt-3 d-flex gap-2 align-items-center">
        <button id="btnAdd" class="btn btn-neon">Add Link</button>
        <button type="button" id="btnClear" class="btn btn-outline-light">Clear</button>
        <div id="formAlert" class="ms-2"></div>
      </div>
    </form>
  </div>

  <div class="footer-note">© HackLink Panel — Admin</div>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
(function(){
  $('#addLinkForm').on('submit', function(e){
    e.preventDefault();
    $('#btnAdd').prop('disabled', true).text('Adding...');
    $('#formAlert').html('');

    const domain = $('#domain').val().trim();
    if(!domain){
      $('#formAlert').html('<div class="alert alert-danger small mt-2">Domain required.</div>');
      $('#btnAdd').prop('disabled', false).text('Add Link');
      return;
    }

    const data = $(this).serialize();
    $.ajax({
      url:'add_link.php',
      method:'POST',
      data:data,
      dataType:'json',
      success:function(res){
        $('#btnAdd').prop('disabled',false).text('Add Link');
        if(!res||!res.ok){
          $('#formAlert').html('<div class="alert alert-danger small mt-2">'+(res?res.msg:'Error')+'</div>');
        } else {
          $('#formAlert').html('<div class="alert alert-success small mt-2">'+res.msg+'</div>');
          // ✅ go to depot so the new link is visible
          setTimeout(()=>{ window.location.href='../link-depo.php?added=1'; }, 1000);
        }
      },
      error:function(){
        $('#btnAdd').prop('disabled',false).text('Add Link');
        $('#formAlert').html('<div class="alert alert-danger small mt-2">Server Error</div>');
      }
    });
  });

  $('#btnClear').on('click',function(){
    $('#addLinkForm')[0].reset();
    $('#formAlert').html('');
  });
})();
</script>
</body>
</html>