<?php
// admin/placements.php — View All Link Placement Activity Logs
// ------------------------------------------------------------
// Shows all auto-placement logs (success / failed / pending)

if (session_status() === PHP_SESSION_NONE) session_start();
require_once "../config.php"; // DB connection

// ✅ Localhost fallback (for testing without login)
if (empty($_SESSION['admin_logged'])) {
    // comment next 2 lines in production
    $_SESSION['admin_logged'] = true;
    $_SESSION['admin_id'] = 1;
}

// ✅ Security check (for real use)
if (empty($_SESSION['admin_logged'])) {
    header("Location: login.php");
    exit;
}

$admin_id = (int)($_SESSION['admin_id'] ?? 1);

// --- fetch placement logs
try {
    $logs = $db->get_results("
        SELECT id, uid, lid, domain, target_url, keyword, status, api_response, created_at 
        FROM k_link_placements 
        ORDER BY id DESC LIMIT 500
    ");
} catch (Throwable $e) {
    $logs = [];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Placement Activity Logs</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.datatables.net/1.13.4/css/dataTables.bootstrap5.min.css" rel="stylesheet">
<style>
body {
  background: #0e0c1d;
  color: #ddd;
  font-family: 'Orbitron', sans-serif;
}
.card {
  background: #161329;
  border: none;
  border-radius: 16px;
  box-shadow: 0 0 12px rgba(120,0,255,0.3);
}
.card h3 { color: #9f7aea; font-weight: 700; }
.badge-status {
  padding: .45em .7em;
  border-radius: .5em;
  font-size: .8em;
  font-weight: 600;
}
.badge-success { background: #22c55e; color: #000; }
.badge-failed { background: #ef4444; }
.badge-pending { background: #facc15; color:#000; }
.table thead { background: #1e1b2e; color:#b6aaff; }
.dataTables_filter input {
  background: #1a1a2e;
  border: none;
  color: #fff;
  padding: 6px;
  border-radius: 6px;
}
.dataTables_wrapper .dataTables_paginate .paginate_button {
  background: #1f1d2e;
  border: none;
  color: #fff!important;
  border-radius: 6px;
  margin: 0 2px;
}
.dataTables_wrapper .dataTables_paginate .paginate_button.current {
  background: #9f7aea!important;
  color: #fff!important;
}
</style>
</head>
<body>
<div class="container-fluid mt-4">
  <div class="card p-4">
    <h3 class="mb-3"><i class="bi bi-activity"></i> Placement Activity Logs</h3>

    <?php if(!$logs): ?>
      <div class="alert alert-warning">No placement activity found.</div>
    <?php else: ?>
      <div class="table-responsive">
        <table id="logTable" class="table table-dark table-striped align-middle" style="width:100%">
          <thead>
            <tr>
              <th>ID</th>
              <th>User</th>
              <th>Link ID</th>
              <th>Domain</th>
              <th>Target URL</th>
              <th>Keyword</th>
              <th>Status</th>
              <th>Response</th>
              <th>Time</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach($logs as $r): 
              $stBadge = match($r->status){
                'success' => '<span class="badge-status badge-success">Success</span>',
                'failed'  => '<span class="badge-status badge-failed">Failed</span>',
                default   => '<span class="badge-status badge-pending">Pending</span>'
              };
              ?>
              <tr>
                <td><?= (int)$r->id ?></td>
                <td><?= (int)$r->uid ?></td>
                <td><?= (int)$r->lid ?></td>
                <td><?= htmlspecialchars($r->domain) ?></td>
                <td><a href="<?= htmlspecialchars($r->target_url) ?>" target="_blank"><?= htmlspecialchars($r->target_url) ?></a></td>
                <td><?= htmlspecialchars($r->keyword) ?></td>
                <td><?= $stBadge ?></td>
                <td>
                  <?php 
                    $res = strip_tags((string)$r->api_response);
                    echo strlen($res)>80 ? substr($res,0,80).'...' : $res;
                  ?>
                </td>
                <td><?= htmlspecialchars($r->created_at) ?></td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    <?php endif; ?>
  </div>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.13.4/js/dataTables.bootstrap5.min.js"></script>
<script>
$(function(){
  $('#logTable').DataTable({
    pageLength: 25,
    order: [[0,'desc']]
  });
});
</script>
</body>
</html>
