<?php
// admin/login.php
$root = dirname(__DIR__);
if (session_status() === PHP_SESSION_NONE) session_start();
include $root . "/config.php"; // ✅ always include DB connection

global $db;

/** Safe esc helper */
function esc($v){
    global $db;
    return isset($db) && method_exists($db,'escape') ? $db->escape($v) : addslashes($v);
}

/** ✅ Ensure log table exists */
try {
    $db->query("CREATE TABLE IF NOT EXISTS k_admin_login_logs (
        id INT AUTO_INCREMENT PRIMARY KEY,
        admin_id INT NULL,
        username VARCHAR(190) NULL,
        ip VARCHAR(45) NULL,
        user_agent TEXT NULL,
        success TINYINT(1) DEFAULT 0,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        INDEX(admin_id),
        INDEX(created_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");
} catch (Throwable $e) {}

/** ✅ Record admin login attempt */
function record_admin_login_force($admin_id, $username, $success = 0){
    global $db;
    try {
        $ip = $_SERVER['HTTP_X_FORWARDED_FOR'] ?? $_SERVER['REMOTE_ADDR'] ?? 'unknown';
        if (strpos($ip, ',') !== false) $ip = trim(explode(',', $ip)[0]);
        $ua = $_SERVER['HTTP_USER_AGENT'] ?? '';
        $admin_id = (int)$admin_id;
        $username = esc($username);
        $ua = esc($ua);
        $ip = esc($ip);
        $ok = (int)$success;
        $db->query("INSERT INTO k_admin_login_logs (admin_id, username, ip, user_agent, success, created_at)
                    VALUES ($admin_id, '$username', '$ip', '$ua', $ok, NOW())");
    } catch (Throwable $e) {
        file_put_contents(__DIR__."/login_error.log", $e->getMessage()."\n", FILE_APPEND);
    }
}

// ✅ already logged in admin → redirect
if (!empty($_SESSION['user']) && ($_SESSION['user']->role ?? '')==='admin') {
    header('Location: index.php'); exit;
}

$msg = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $ident = trim($_POST['ident'] ?? '');
    $pass  = $_POST['password'] ?? '';

    if ($ident === '' || $pass === '') {
        $msg = '⚠️ সব ফিল্ড পূরণ করুন';
    } else {
        $i = esc($ident);
        $found = false;

        // Check in k_admins
        $admin = $db->get_row("SELECT * FROM k_admins WHERE username='{$i}' OR email='{$i}' LIMIT 1", ARRAY_A);
        if ($admin && password_verify($pass, $admin['password'])) {
            $_SESSION['user'] = (object)[
                'id' => (int)$admin['user_id'],
                'username' => $admin['username'],
                'email' => $admin['email'],
                'role' => 'admin'
            ];
            record_admin_login_force($admin['user_id'], $admin['username'], 1);
            header('Location: index.php'); exit;
        }

        // Check in k_users (role='admin')
        $usr = $db->get_row("SELECT * FROM k_users WHERE (username='{$i}' OR email='{$i}') AND role='admin' LIMIT 1", ARRAY_A);
        if ($usr && password_verify($pass, $usr['password'])) {
            $_SESSION['user'] = (object)[
                'id' => (int)$usr['id'],
                'username' => $usr['username'],
                'email' => $usr['email'],
                'role' => 'admin'
            ];
            record_admin_login_force($usr['id'], $usr['username'], 1);
            header('Location: index.php'); exit;
        }

        // ❌ Failed login
        record_admin_login_force(0, $ident, 0);
        $msg = '❌ ভুল ইউজারনেম বা পাসওয়ার্ড';
    }
}
?>
<!doctype html>
<html lang="bn">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Admin Login</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<style>
body{background:#030611;color:#e6eef8;font-family:Inter,system-ui;padding-top:60px;}
.box{max-width:420px;margin:auto;padding:25px;border-radius:12px;background:linear-gradient(180deg,rgba(255,255,255,0.03),rgba(255,255,255,0.01));border:1px solid rgba(96,165,250,0.08);box-shadow:0 12px 36px rgba(0,0,0,.6);}
.btn-hack{background:linear-gradient(90deg,#ef4444,#f97316);border:0}
.err{background:rgba(239,68,68,0.1);color:#fca5a5;padding:8px;border-radius:8px;margin-bottom:10px;text-align:center}
</style>
</head>
<body>
<div class="box">
<h4 class="mb-3 text-center text-warning">⚙️ Admin Login</h4>
<?php if($msg): ?><div class="err"><?= htmlspecialchars($msg) ?></div><?php endif; ?>
<form method="post">
<div class="mb-3">
<label class="form-label">Username / Email</label>
<input type="text" name="ident" class="form-control" required>
</div>
<div class="mb-3">
<label class="form-label">Password</label>
<input type="password" name="password" class="form-control" required>
</div>
<button class="btn btn-hack w-100">Login</button>
</form>
</div>
</body></html>
