<?php
include __DIR__ . "/_bootstrap.php";

// Ensure $db is defined
if (!isset($db) || !is_object($db)) {
    die("Error: Database connection not established. Check _bootstrap.php configuration.");
}

// ✅ Ensure table exists
try {
    $db->query("
        CREATE TABLE IF NOT EXISTS k_admin_login_logs (
            id INT AUTO_INCREMENT PRIMARY KEY,
            admin_id INT NULL,
            username VARCHAR(190) NULL,
            ip VARCHAR(45) NULL,
            user_agent TEXT NULL,
            success TINYINT(1) DEFAULT 0,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            INDEX(admin_id),
            INDEX(created_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    ");
} catch (Throwable $e) {
    die("Error creating table: " . htmlspecialchars($e->getMessage()));
}

// ✅ Filters
$where = "1=1";
$username = trim($_GET['username'] ?? '');
$ip = trim($_GET['ip'] ?? '');
$status = $_GET['success'] ?? '';

if ($username !== '') {
    $where .= " AND username LIKE '%" . $db->escape($username) . "%'";
}
if ($ip !== '') {
    $where .= " AND ip LIKE '%" . $db->escape($ip) . "%'";
}
if ($status !== '' && in_array($status, ['0', '1'])) {
    $where .= " AND success = " . (int)$status;
}

// ✅ Fetch logs
try {
    $rows = $db->get_results("SELECT * FROM k_admin_login_logs WHERE $where ORDER BY id DESC LIMIT 200");
    if ($rows === false) {
        throw new Exception("Query returned false, likely due to a syntax error or connection issue.");
    }
} catch (Throwable $e) {
    die("Error fetching logs: " . htmlspecialchars($e->getMessage()));
}

// ✅ Quick Stats
try {
    $total_all = (int)$db->get_var("SELECT COUNT(*) FROM k_admin_login_logs");
    $total_success = (int)$db->get_var("SELECT COUNT(*) FROM k_admin_login_logs WHERE success = 1");
    $total_failed = (int)$db->get_var("SELECT COUNT(*) FROM k_admin_login_logs WHERE success = 0");
    $success_rate = $total_all ? round(($total_success / $total_all) * 100, 1) : 0;
} catch (Throwable $e) {
    die("Error fetching stats: " . htmlspecialchars($e->getMessage()));
}
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>🧠 Admin Login Logs</title>
<meta name="viewport" content="width=device-width,initial-scale=1">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<style>
body {
  background: #060717;
  color: #e6eef8;
  font-family: 'Share Tech Mono', monospace;
}
h2 { color: #00e6ff; font-weight: 700; margin-bottom: 20px; text-shadow: 0 0 6px rgba(0,230,255,.6); }
.card { background: rgba(255,255,255,0.02); border: 1px solid rgba(0,255,157,0.1); border-radius: 14px;
  box-shadow: 0 0 25px rgba(0,255,157,.05), inset 0 0 10px rgba(0,230,255,.08); }
.badge-ok { background: linear-gradient(90deg,#00ff9d,#00e6ff); color: #001214; }
.badge-fail { background: linear-gradient(90deg,#ff5f5f,#ff9f7f); color: #120000; }
.search-box { background: rgba(0,0,0,0.3); border-radius: 12px; padding: 15px; margin-bottom: 20px; }
input.form-control { background: #0d1326; color: #fff; border: 1px solid rgba(255,255,255,0.08); }
input.form-control:focus { border-color: #00e6ff; box-shadow: 0 0 10px rgba(0,230,255,0.2); }
.table thead th { color: #00e6ff; }
.table tbody tr:hover { background: rgba(0,255,157,0.05); }
.navx {
  display: flex; flex-wrap: wrap; gap: 8px;
  background: linear-gradient(90deg,rgba(255,255,255,0.04),rgba(255,255,255,0.02));
  border: 1px solid rgba(255,255,255,0.05);
  border-radius: 12px;
  padding: 10px 15px;
  box-shadow: 0 8px 30px rgba(0,0,0,0.6);
  justify-content: center;
  margin-bottom: 25px;
}
.navx a {
  text-decoration: none; color: #e6eef8; background: rgba(96,165,250,0.1);
  padding: 8px 14px; border-radius: 8px; font-weight: 500; transition: .2s;
}
.navx a:hover {
  background: linear-gradient(90deg,#60a5fa,#a855f7);
  color: #fff;
  text-shadow: 0 0 8px rgba(96,165,250,0.5);
}
.logout-btn {
  background: linear-gradient(90deg,#ef4444,#b91c1c);
  padding: 6px 14px; border-radius: 8px;
  color: #fff; text-decoration: none; font-weight: 600;
  transition: .2s;
}
.logout-btn:hover { box-shadow: 0 0 15px rgba(239,68,68,.5); color: #fff; }
.refresh-info { text-align: right; color: #00ff9d; font-size: 13px; }
canvas { max-height: 240px !important; margin-top: 20px; }
</style>
</head>
<body class="p-4">

<!-- 🔥 Navbar -->
<div class="container my-3">
  <div class="navx">
    <a href="index.php">🏠 Home</a>
    <a href="users.php">👥 Users</a>
    <a href="announcements.php">📢 Announcements</a>
    <a href="broken_links.php">🧩 Broken Links</a>
    <a href="login_logs.php" style="background:linear-gradient(90deg,#60a5fa,#a855f7);color:#fff;">🧠 Admin Logs</a>
    <a href="user_login_logs.php">📜 User Login Logs</a>
    <a href="monitors.php">🔗 URL Monitor</a>
    <a href="deleted_sites.php" style="color:#ff7171;">🚫 Removed Sites</a>
    <a href="refunds.php">💸 Refunds</a>
    <a href="../index.php">🌐 Front</a>
    <a href="logout.php" class="logout-btn">Logout</a>
  </div>
</div>

<div class="container">
  <div class="d-flex justify-content-between align-items-center mb-3">
    <h2>🧠 Admin Login Logs</h2>
    <div class="refresh-info">⏱️ Auto-refresh every <strong>30s</strong></div>
  </div>

  <div class="row g-3 mb-4">
    <div class="col-md-4">
      <div class="card p-3 text-center">
        <h5>Total Attempts</h5>
        <h3><?php echo htmlspecialchars($total_all); ?></h3>
      </div>
    </div>
    <div class="col-md-4">
      <div class="card p-3 text-center">
        <h5>Successful</h5>
        <h3 class="text-success"><?php echo htmlspecialchars($total_success); ?></h3>
      </div>
    </div>
    <div class="col-md-4">
      <div class="card p-3 text-center">
        <h5>Success Rate</h5>
        <h3 class="text-info"><?php echo htmlspecialchars($success_rate); ?>%</h3>
      </div>
    </div>
  </div>

  <!-- 📈 Chart -->
  <div class="card p-4 mb-4">
    <h5>Login Success vs Failed</h5>
    <canvas id="loginChart"></canvas>
  </div>

  <!-- 🔍 Filters -->
  <div class="search-box">
    <form method="get" class="row g-2 align-items-center">
      <div class="col-md-3">
        <input type="text" name="username" value="<?php echo htmlspecialchars($username); ?>" class="form-control" placeholder="Username">
      </div>
      <div class="col-md-3">
        <input type="text" name="ip" value="<?php echo htmlspecialchars($ip); ?>" class="form-control" placeholder="IP">
      </div>
      <div class="col-md-3">
        <select name="success" class="form-select">
          <option value="">All</option>
          <option value="1" <?php echo $status === '1' ? 'selected' : ''; ?>>Success</option>
          <option value="0" <?php echo $status === '0' ? 'selected' : ''; ?>>Failed</option>
        </select>
      </div>
      <div class="col-md-2">
        <button class="btn btn-sm btn-primary w-100">Filter</button>
      </div>
    </form>
  </div>

  <!-- 🧾 Logs Table -->
  <div class="card p-3">
    <div class="table-responsive">
      <table class="table table-sm align-middle">
        <thead>
          <tr>
            <th>#</th>
            <th>Username</th>
            <th>IP</th>
            <th>User Agent</th>
            <th>Status</th>
            <th>Date</th>
          </tr>
        </thead>
        <tbody>
        <?php if (empty($rows)): ?>
          <tr><td colspan="6" class="text-center text-muted">
            No login records found. <?php echo $total_all === 0 ? "The table is empty." : "Try adjusting the filters."; ?>
          </td></tr>
        <?php else: ?>
          <?php foreach ($rows as $r): ?>
            <tr>
              <td><?php echo htmlspecialchars($r->id); ?></td>
              <td><?php echo htmlspecialchars($r->username ?? '-'); ?></td>
              <td><code><?php echo htmlspecialchars($r->ip ?? '-'); ?></code></td>
              <td><small><?php echo htmlspecialchars(substr($r->user_agent ?? '', 0, 80)); ?><?php echo strlen($r->user_agent ?? '') > 80 ? '…' : ''; ?></small></td>
              <td><?php echo $r->success ? '<span class="badge badge-ok">SUCCESS</span>' : '<span class="badge badge-fail">FAILED</span>'; ?></td>
              <td><small><?php echo htmlspecialchars($r->created_at); ?></small></td>
            </tr>
          <?php endforeach; ?>
        <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<script>
const ctx = document.getElementById('loginChart');
new Chart(ctx, {
  type: 'doughnut',
  data: {
    labels: ['Success', 'Failed'],
    datasets: [{
      data: [<?php echo $total_success; ?>, <?php echo $total_failed; ?>],
      backgroundColor: ['#00ff9d', '#ff5f5f'],
      borderColor: 'rgba(255,255,255,0.1)',
      borderWidth: 1,
      hoverOffset: 8
    }]
  },
  options: {
    plugins: { legend: { labels: { color: '#fff' } } },
    cutout: '70%'
  }
});

// 🔄 auto-refresh
setTimeout(() => location.reload(), 30000);
</script>
</body>
</html>