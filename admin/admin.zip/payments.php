<?php
// admin/payments.php
include __DIR__ . "/_bootstrap.php";
global $db, $pdo;

// ✅ Admin check
if (($user->role ?? '') !== 'admin') {
    header("Location: ../login.php");
    exit;
}

// --- Handle Approve / Reject ---
if (isset($_GET['action'], $_GET['id'])) {
    $id = (int)$_GET['id'];
    $action = $_GET['action'];
    $payment = $db->get_row("SELECT * FROM k_payments WHERE id={$id}");

    if ($payment) {
        if ($action === 'approve' && $payment->status === 'pending') {
            $db->query("UPDATE k_payments SET status='approved', approved_at=NOW() WHERE id={$id}");

            // ✅ ইউজারকে ক্রেডিট ও প্যাকেজ যোগ করো
            $uid = (int)$payment->uid;
            $amount = (float)$payment->amount;
            $paket_id = (int)$payment->paket_id;

            // ইউজার ও প্যাকেজ ডাটা বের করো
            $userData  = $db->get_row("SELECT id, username, kredi FROM k_users WHERE id={$uid}");
            $paketData = $db->get_row("SELECT id, baslik, kota, sure FROM k_paketler WHERE id={$paket_id}");

            if ($userData && $paketData) {
                // 💰 ক্রেডিট যোগ
                $db->query("UPDATE k_users SET kredi = kredi + {$amount} WHERE id={$uid}");

                // 🎯 প্যাকেজ সেট করো
                $expire = date('Y-m-d H:i:s', strtotime("+{$paketData->sure} days"));
                $db->query("
                    UPDATE k_users 
                    SET paket_id = {$paketData->id},
                        kota = {$paketData->kota},
                        paket_expire = '{$expire}'
                    WHERE id = {$uid}
                ");

                // লগ রেকর্ড
                $reason = "Payment approved — {$paketData->baslik} ({$paketData->kota} quota)";
                try {
                    $stmt = $pdo->prepare("INSERT INTO k_credits_log (uid, delta, reason, admin_id, created_at)
                                           VALUES (?, ?, ?, ?, NOW())");
                    $stmt->execute([$uid, $amount, $reason, $user->id]);
                } catch (Throwable $e) {
                    error_log("Credit log insert failed: " . $e->getMessage());
                }
            }

            $msg = "✅ Payment #{$id} approved — Package & credits added successfully.";
        } 
        elseif ($action === 'reject' && $payment->status === 'pending') {
            $db->query("UPDATE k_payments SET status='rejected', approved_at=NOW() WHERE id={$id}");
            $msg = "❌ Payment #{$id} rejected.";
        }

        header("Location: payments.php?msg=" . urlencode($msg));
        exit;
    }
}

// --- Fetch All Payments ---
$rows = $db->get_results("
    SELECT p.*, u.username, pk.baslik AS paket_name
    FROM k_payments p
    LEFT JOIN k_users u ON u.id = p.uid
    LEFT JOIN k_paketler pk ON pk.id = p.paket_id
    ORDER BY p.created_at DESC
");
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>💰 Payments — Admin Panel</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Share+Tech+Mono&display=swap" rel="stylesheet">
<style>
body{background:#060717;color:#e6eef8;font-family:'Share Tech Mono',monospace;}
h2{color:#00e6ff;text-shadow:0 0 10px rgba(0,230,255,.5);}
.table thead th{color:#00e6ff;}
.table tbody tr:hover{background:rgba(0,255,157,0.05);}
.badge-pending{background:linear-gradient(90deg,#facc15,#fbbf24);color:#000;}
.badge-approved{background:linear-gradient(90deg,#00ff9d,#00e6ff);color:#001214;}
.badge-rejected{background:linear-gradient(90deg,#ff5f5f,#ff9f7f);color:#fff;}
.btn-sm{font-size:13px;padding:3px 8px;border-radius:6px;}
.cardx{background:rgba(255,255,255,0.02);border:1px solid rgba(0,255,157,0.1);border-radius:12px;padding:20px;}
.nav-back{color:#00e6ff;text-decoration:none;}
.nav-back:hover{text-decoration:underline;}
</style>
</head>
<body class="p-4">
<div class="container">
  <div class="d-flex justify-content-between align-items-center mb-3">
    <h2>💰 Payment Requests</h2>
    <a href="index.php" class="nav-back">⬅ Dashboard</a>
  </div>

  <?php if(isset($_GET['msg'])): ?>
    <div class="alert alert-info"><?=htmlspecialchars($_GET['msg'])?></div>
  <?php endif; ?>

  <div class="cardx">
    <div class="table-responsive">
      <table class="table table-sm align-middle">
        <thead>
          <tr>
            <th>#</th>
            <th>User</th>
            <th>Package</th>
            <th>Amount</th>
            <th>Currency</th>
            <th>Txn ID</th>
            <th>Status</th>
            <th>Date</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
        <?php if(!$rows): ?>
          <tr><td colspan="9" class="text-center text-muted">No payment records found.</td></tr>
        <?php else: foreach($rows as $r): ?>
          <tr>
            <td><?=$r->id?></td>
            <td><?=htmlspecialchars($r->username ?? '-')?></td>
            <td><?=htmlspecialchars($r->paket_name ?? '-')?></td>
            <td><?=number_format($r->amount,2)?></td>
            <td><?=$r->currency?></td>
            <td><code><?=htmlspecialchars($r->txn_id)?></code></td>
            <td>
              <?php if($r->status==='approved'){ ?>
                <span class="badge badge-approved">Approved</span>
              <?php } elseif($r->status==='rejected'){ ?>
                <span class="badge badge-rejected">Rejected</span>
              <?php } else { ?>
                <span class="badge badge-pending">Pending</span>
              <?php } ?>
            </td>
            <td><small><?=htmlspecialchars($r->created_at)?></small></td>
            <td>
              <?php if($r->status==='pending'){ ?>
                <a href="?action=approve&id=<?=$r->id?>" class="btn btn-success btn-sm">Approve</a>
                <a href="?action=reject&id=<?=$r->id?>" class="btn btn-danger btn-sm">Reject</a>
              <?php } else { ?>
                <span class="text-muted">—</span>
              <?php } ?>
            </td>
          </tr>
        <?php endforeach; endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>
</body>
</html>
